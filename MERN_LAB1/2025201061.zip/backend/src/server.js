import express from "express";
import dotenv from "dotenv";
import router from "./routes/notesRouter.js";

dotenv.config();

const app = express();

// Middleware
app.use(express.json());
app.use("/api/notes", router);

// Use a flag to track the connection status
let isDbConnected = false;

// Immediately-invoked async function to connect to the database
(async () => {
  try {
    const PORT = process.env.PORT || 5001;

    // Only start the server if not in a test environment
    if (process.env.NODE_ENV !== "test") {
      app.listen(PORT, () => {
        console.log("Server started on PORT:", PORT);
      });
    }
  } catch (err) {
    console.error("Failed to connect to the database or start the server:", err);
    process.exit(1);
  }
})();

// Export the app object after the connection is attempted
export default app;