import { v4 as uuidv4 } from "uuid"; // Import uuid for generating custom IDs
import { MongoClient } from "mongodb";
import dotenv from "dotenv";

dotenv.config();
const uri = process.env.MONGODB_URI; 
let client;
let notesCollection;
let isConnected = false;
if (!uri) {
  console.error("MongoDB URI not found. Please set MONGODB_URI in your .env file.");
  process.exit(1);
}

export async function connectDB() {
  if (!isConnected) {
    client = new MongoClient(uri);
    try {
      await client.connect();
      const db = client.db();
      notesCollection = db.collection("notes");
      isConnected = true;
      console.log("Connected to MongoDB!");
    } catch (error) {
      console.error("Error connecting to MongoDB:", error);
      process.exit(1);
    }
  }
}

export async function closeDB() {
  if (client) {
    await client.close();
    console.log("MongoDB connection closed.");
  }
}
// GET all notes
export async function getAllNotes(req, res) {
  try {
    const allNotes = await notesCollection.find({}).toArray();
    res.status(200).json(allNotes);
  } catch (error) {
    res.status(500).json({ error: "Failed to retrieve notes" });
  }
}

// POST create note
export async function createNotes(req, res) {
  const { title, content } = req.body;
  if (!title || !content)
    return res.status(400).json({ error: "Title and content required" });

  try {
    // Generate a custom string ID using uuid
    const note = { id: uuidv4(), title, content };
    await notesCollection.insertOne(note);
    res.status(201).json(note);
  } catch (error) {
    res.status(500).json({ error: "Failed to create note" });
  }
}

// PUT update note by id
export async function updateNotes(req, res) {
  const { id } = req.params;
  const { title, content } = req.body;

  if (!title || !content)
    return res.status(400).json({ error: "Title and content required" });

  try {
    const updateResult = await notesCollection.updateOne(
      { id: id }, // Query by the custom 'id' field
      { $set: { title, content } }
    );

    if (updateResult.matchedCount === 0) {
      return res.status(404).json({ error: "Note not found" });
    }

    const updatedNote = await notesCollection.findOne({ id: id });
    res.status(200).json(updatedNote);
  } catch (error) {
    res.status(500).json({ error: "Failed to update note" });
  }
}

// DELETE note by id
export async function deleteNotes(req, res) {
  const { id } = req.params;
  
  try {
    const deletedNote = await notesCollection.findOne({ id: id }); // Find by 'id'
    if (!deletedNote) {
      return res.status(404).json({ error: "Note not found" });
    }
    
    await notesCollection.deleteOne({ id: id }); // Delete by 'id'
    
    res.status(200).json(deletedNote);
  } catch (error) {
    res.status(500).json({ error: "Failed to delete note" });
  }
}

// Resets the notes collection for each test
export function resetNotes() {
  try {
    if (notesCollection) {
      notesCollection.deleteMany({});
      console.log("All notes deleted from database.");
    }
  } catch (error) {
    console.error("Failed to reset notes:", error);
  }
}